package Analyzer;
import comparator.Tests;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;

public class UnicornLogAnalyzer {

	private JFrame frame;
	private final Action action = new SwingAction();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UnicornLogAnalyzer window = new UnicornLogAnalyzer();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UnicornLogAnalyzer() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem mntmOpen = new JMenuItem("Open ...");
		mnFile.add(mntmOpen);
		
		JMenuItem mntmSaveReportAs = new JMenuItem("Save Report as ...");
		mnFile.add(mntmSaveReportAs);
		
		JMenu mnRangeBy = new JMenu("Range by...");
		menuBar.add(mnRangeBy);
		
		JMenuItem mntmMaximumTime = new JMenuItem("Maximum time");
		mnRangeBy.add(mntmMaximumTime);
		
		JMenuItem mntmAverageTime = new JMenuItem("Average Time");
		mnRangeBy.add(mntmAverageTime);
		
		JMenuItem mntmTotalTime = new JMenuItem("Total Time");
		mnRangeBy.add(mntmTotalTime);
		
		
		JMenu mnOtherReports = new JMenu("Other Reports");
		menuBar.add(mnOtherReports);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setBounds(6, 6, 252, 244);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnShowReport = new JButton("Show Report");
		btnShowReport.setAction(action);
		btnShowReport.setBounds(298, 186, 117, 29);
		frame.getContentPane().add(btnShowReport);
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		
		}
	}
}
