package comparator;

public class Pair {
	public String string;
	public int nbr;

	public Pair(String s, int i) {
		string = s;
		nbr = i;
	}
}
